export function createData(
    nameCustomer,
    custNumber,
    invoiceId,
    totalOpenAmount,
    dueInDate,
    notes
  ) {
    return {
    nameCustomer,
    custNumber,
    invoiceId,
    totalOpenAmount,
    dueInDate,
    notes
    };
  }
  