export const SERVER_URL = 'http://localhost:8081/';
export const ROLL_NUMBER = '1805096';
